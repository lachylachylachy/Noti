import { useEffect, useMemo, useRef, useState, type KeyboardEvent } from "react";
import { getCurrentWindow } from "@tauri-apps/api/window";
import "./App.css";

type Priority = "Low" | "Medium" | "High" | "Urgent";
type MessageKind = "note" | "meta_prompt" | "ack";

type ThreadMessage = {
  id: string;
  role: "user" | "assistant";
  text: string;
  kind: MessageKind;
  typing?: boolean;
  createdAt: string;
};

type NoteThread = {
  id: number;
  title: string;
  category: string;
  priority: Priority;
  dueDate: string;
  dueTime: string;
  createdAt: string;
  updatedAt: string;
  messages: ThreadMessage[];
};

const THREADS_STORAGE_KEY = "noti-threads-v3-option1";
const PRIORITIES: Priority[] = ["Low", "Medium", "High", "Urgent"];
const CATEGORIES = ["Unassigned", "Personal", "Work", "Projects", "Ideas", "Study"];

function createMessage(
  role: "user" | "assistant",
  text: string,
  kind: MessageKind,
  typing = false
): ThreadMessage {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
    role,
    text,
    kind,
    typing,
    createdAt: new Date().toLocaleString(),
  };
}

function normaliseThread(thread: Partial<NoteThread>): NoteThread {
  const now = new Date().toLocaleString();

  return {
    id: thread.id ?? Date.now(),
    title: thread.title ?? "Untitled Note",
    category: thread.category ?? "Unassigned",
    priority: thread.priority ?? "Medium",
    dueDate: thread.dueDate ?? "",
    dueTime: thread.dueTime ?? "",
    createdAt: thread.createdAt ?? now,
    updatedAt: thread.updatedAt ?? now,
    messages: Array.isArray(thread.messages)
      ? thread.messages.map((message) => ({
          id: message.id ?? `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
          role: message.role === "assistant" ? "assistant" : "user",
          text: message.text ?? "",
          kind: message.kind ?? "note",
          typing: Boolean(message.typing),
          createdAt: message.createdAt ?? now,
        }))
      : [],
  };
}

function App() {
  const appWindow = getCurrentWindow();
  const mainInputRef = useRef<HTMLTextAreaElement | null>(null);
  const threadInputRef = useRef<HTMLTextAreaElement | null>(null);

  const [isFullscreen, setIsFullscreen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [draft, setDraft] = useState("");
  const [threadDraft, setThreadDraft] = useState("");
  const [selectedThreadId, setSelectedThreadId] = useState<number | null>(null);

  const [threads, setThreads] = useState<NoteThread[]>(() => {
    try {
      const saved = localStorage.getItem(THREADS_STORAGE_KEY);
      return saved ? JSON.parse(saved).map(normaliseThread) : [];
    } catch {
      return [];
    }
  });

  const hasThreads = threads.length > 0;
  const selectedThread = threads.find((thread) => thread.id === selectedThreadId) ?? null;
  const recentThreads = useMemo(() => [...threads].sort((a, b) => b.id - a.id).slice(0, 4), [threads]);

  useEffect(() => {
    localStorage.setItem(THREADS_STORAGE_KEY, JSON.stringify(threads));
  }, [threads]);

  useEffect(() => {
    async function syncFullscreenState() {
      const fullscreen = await appWindow.isFullscreen();
      setIsFullscreen(fullscreen);
    }

    syncFullscreenState();
    const unlistenResize = appWindow.onResized(syncFullscreenState);

    return () => {
      unlistenResize.then((fn) => fn());
    };
  }, [appWindow]);

  async function closeWindow() {
    await appWindow.close();
  }

  async function minimiseWindow() {
    await appWindow.minimize();
  }

  async function toggleFullscreen() {
    const fullscreen = await appWindow.isFullscreen();
    await appWindow.setFullscreen(!fullscreen);
    setIsFullscreen(!fullscreen);
  }

  function updateThread(threadId: number, updater: (thread: NoteThread) => NoteThread) {
    setThreads((current) => current.map((thread) => (thread.id === threadId ? updater(thread) : thread)));
  }

  function finishTyping(threadId: number, messageId: string) {
    window.setTimeout(() => {
      updateThread(threadId, (thread) => ({
        ...thread,
        messages: thread.messages.map((message) =>
          message.id === messageId ? { ...message, typing: false } : message
        ),
      }));
    }, 650);
  }

  function addAssistantMessage(threadId: number, text: string, kind: MessageKind = "ack") {
    const assistant = createMessage("assistant", text, kind, true);

    updateThread(threadId, (thread) => ({
      ...thread,
      updatedAt: new Date().toLocaleString(),
      messages: [...thread.messages, assistant],
    }));

    finishTyping(threadId, assistant.id);
  }

  function createThread(content: string) {
    const trimmed = content.trim();
    if (!trimmed) return;

    const now = new Date().toLocaleString();
    const threadId = Date.now();
    const userMessage = createMessage("user", trimmed, "note");
    const assistantMessage = createMessage(
      "assistant",
      "New note added. Add a date, time, priority, or category if you want.",
      "meta_prompt",
      true
    );

    const newThread: NoteThread = {
      id: threadId,
      title: trimmed,
      category: "Unassigned",
      priority: "Medium",
      dueDate: "",
      dueTime: "",
      createdAt: now,
      updatedAt: now,
      messages: [userMessage, assistantMessage],
    };

    setThreads((current) => [newThread, ...current]);
    setSelectedThreadId(threadId);
    setDraft("");
    setThreadDraft("");
    finishTyping(threadId, assistantMessage.id);

    requestAnimationFrame(() => {
      threadInputRef.current?.focus();
    });
  }

  function appendToSelectedThread() {
    if (!selectedThread || !threadDraft.trim()) {
      createThread(threadDraft);
      return;
    }

    const userMessage = createMessage("user", threadDraft.trim(), "note");
    const assistantMessage = createMessage("assistant", getUpdateReply(), "ack", true);

    updateThread(selectedThread.id, (thread) => ({
      ...thread,
      updatedAt: new Date().toLocaleString(),
      messages: [...thread.messages, userMessage, assistantMessage],
    }));

    setThreadDraft("");
    finishTyping(selectedThread.id, assistantMessage.id);
  }

  function updateThreadField<K extends keyof NoteThread>(threadId: number, field: K, value: NoteThread[K]) {
    updateThread(threadId, (thread) => ({
      ...thread,
      [field]: value,
      updatedAt: new Date().toLocaleString(),
    }));

    addAssistantMessage(threadId, getUpdateReply(), "ack");
  }

  function startNewThread() {
    setSelectedThreadId(null);
    setDraft("");
    setThreadDraft("");

    requestAnimationFrame(() => {
      mainInputRef.current?.focus();
    });
  }

  function handleMainKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      createThread(draft);
    }
  }

  function handleThreadKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      appendToSelectedThread();
    }
  }

  function formatEditedTime(thread: NoteThread) {
    if (!thread.updatedAt) return "Edited recently";
    return "Edited recently";
  }

  return (
    <div className={`app-shell option-one-shell ${isFullscreen ? "is-fullscreen" : ""}`}>
      <section className="floating-stage" onMouseDown={() => setProfileOpen(false)}>
        <div className="workspace-card" onMouseDown={(event) => event.stopPropagation()}>
          <header className="workspace-topbar" onMouseDown={() => appWindow.startDragging()}>
            <div className="workspace-brand">
              <div className="workspace-logo">⌘</div>
              <span>Noti</span>
            </div>

            <div className="workspace-actions">
              <button className="topbar-icon-button" title="Search">⌕</button>
              <button className="topbar-icon-button" title="Recent threads">▦</button>
              <button className="topbar-icon-button" title="Layout">☷</button>

              <div className="profile-wrapper">
                <button
                  className="profile-button"
                  onClick={(event) => {
                    event.stopPropagation();
                    setProfileOpen((current) => !current);
                  }}
                  title="Profile"
                >
                  LB
                </button>

                <div className={`profile-dropdown ${profileOpen ? "profile-dropdown-open" : ""}`}>
                  <div className="profile-header">
                    <div className="profile-avatar">LB</div>
                    <div>
                      <strong>Lachy Beasley</strong>
                      <p>Noti Workspace</p>
                    </div>
                  </div>

                  <button>Profile</button>
                  <button>Settings</button>
                  <button>Appearance</button>
                  <button>Help</button>
                  <button className="danger-option">Log out</button>
                </div>
              </div>

              <button className="new-note-button" onClick={startNewThread}>+ New</button>

              <div className="window-controls-inline">
                <button onClick={minimiseWindow} title="Minimise">—</button>
                <button onClick={toggleFullscreen} title="Fullscreen">□</button>
                <button onClick={closeWindow} title="Close">×</button>
              </div>
            </div>
          </header>

          <main className="workspace-main">
            <section className={`hero-composer ${selectedThread ? "hero-composer-compact" : ""}`}>
              <h1>{getGreeting()}, Lachy <span /></h1>

              <div className="main-composer-card">
                <textarea
                  ref={mainInputRef}
                  className="main-composer-input"
                  placeholder="What's on your mind?"
                  value={draft}
                  onChange={(event) => setDraft(event.target.value)}
                  onKeyDown={handleMainKeyDown}
                  autoFocus
                />

                <div className="composer-action-row">
                  <button>▣ Note</button>
                  <button>▢ Task</button>
                  <button>◷ Reminder</button>
                  <button>⌘ Code</button>
                  <button>⇧ Upload</button>
                  <button className="composer-mic">◌</button>
                </div>
              </div>
            </section>

            {selectedThread && (
              <section className="thread-layer">
                {selectedThread.messages.map((message, index) => {
                  const showMetaControls =
                    message.role === "assistant" &&
                    message.kind === "meta_prompt" &&
                    index === 1;

                  return (
                    <div
                      key={message.id}
                      className={`message-row ${message.role === "user" ? "message-user" : "message-noti"}`}
                    >
                      {message.role === "assistant" && <div className="noti-avatar">N</div>}

                      <div className={`message-bubble ${message.role === "user" ? "user-bubble" : "noti-bubble"}`}>
                        {message.role === "assistant" ? (
                          <>
                            {message.typing ? (
                              <div className="typing-line">
                                <span className="typing-dot" />
                                <span className="typing-dot" />
                                <span className="typing-dot" />
                              </div>
                            ) : (
                              <div className="assistant-copy">
                                <strong>{message.text}</strong>
                              </div>
                            )}

                            {showMetaControls && (
                              <div className="metadata-grid">
                                <label>
                                  Date
                                  <input
                                    type="date"
                                    value={selectedThread.dueDate}
                                    onChange={(event) => updateThreadField(selectedThread.id, "dueDate", event.target.value)}
                                  />
                                </label>

                                <label>
                                  Time
                                  <input
                                    type="time"
                                    value={selectedThread.dueTime}
                                    onChange={(event) => updateThreadField(selectedThread.id, "dueTime", event.target.value)}
                                  />
                                </label>

                                <label>
                                  Priority
                                  <div className="minimal-select-wrap">
                                    <select
                                      value={selectedThread.priority}
                                      onChange={(event) => updateThreadField(selectedThread.id, "priority", event.target.value as Priority)}
                                    >
                                      {PRIORITIES.map((priority) => <option key={priority}>{priority}</option>)}
                                    </select>
                                  </div>
                                </label>

                                <label>
                                  Category
                                  <div className="minimal-select-wrap">
                                    <select
                                      value={selectedThread.category}
                                      onChange={(event) => updateThreadField(selectedThread.id, "category", event.target.value)}
                                    >
                                      {CATEGORIES.map((category) => <option key={category}>{category}</option>)}
                                    </select>
                                  </div>
                                </label>
                              </div>
                            )}
                          </>
                        ) : (
                          message.text
                        )}
                      </div>
                    </div>
                  );
                })}
              </section>
            )}

            <section className="recent-section">
              <div className="recent-header">Recent threads</div>

              <div className="recent-grid">
                {recentThreads.map((thread) => (
                  <button
                    key={thread.id}
                    className={`recent-thread-card ${selectedThreadId === thread.id ? "recent-thread-card-active" : ""}`}
                    onClick={() => setSelectedThreadId(thread.id)}
                  >
                    <span className="thread-category-dot">{getCategoryIcon(thread.category)}</span>
                    <strong>{thread.category}</strong>
                    <p>{thread.title}</p>
                    <small>{formatEditedTime(thread)}</small>
                  </button>
                ))}

                <button className="new-thread-card" onClick={startNewThread}>
                  <span>+</span>
                  <p>New thread</p>
                </button>
              </div>
            </section>
          </main>

          {hasThreads && (
            <section className="bottom-composer floating-bottom-composer">
              <button className="composer-icon-button" title="New note" onClick={startNewThread}>+</button>

              <textarea
                ref={threadInputRef}
                className="bottom-composer-input"
                placeholder={selectedThread ? "Write more, or add to the selected note..." : "Ask anything or capture a thought..."}
                value={threadDraft}
                onChange={(event) => setThreadDraft(event.target.value)}
                onKeyDown={handleThreadKeyDown}
              />

              <button className="composer-icon-button" title="Attach">⌘</button>
              <button className="composer-icon-button" title="Voice input">◌</button>
              <button className="composer-send-button" onClick={appendToSelectedThread} title="Submit">➤</button>
            </section>
          )}

          <div className="command-hint">⌘ K to search anything</div>
        </div>
      </section>
    </div>
  );
}

function getGreeting() {
  const hour = new Date().getHours();

  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

function getCategoryIcon(category: string) {
  switch (category) {
    case "Personal":
      return "●";
    case "Work":
      return "◆";
    case "Projects":
      return "▣";
    case "Ideas":
      return "✦";
    case "Study":
      return "◐";
    default:
      return "⌁";
  }
}

function getUpdateReply() {
  const replies = ["Updated.", "Noted.", "Saved.", "Added."];
  return replies[Math.floor(Math.random() * replies.length)];
}

export default App;
